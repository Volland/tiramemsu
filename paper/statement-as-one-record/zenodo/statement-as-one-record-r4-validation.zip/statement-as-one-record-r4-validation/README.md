# Validation archive: When Is a Temporal Statement Store a Statement Graph?

Revision 4, 12 October 2026. Volodymyr Pavlyshyn. Companion to the PDF in the same Zenodo
record. Source repository: https://github.com/Volland/tiramemsu
(paper/statement-as-one-record/).

## Contents

- `paper/`: LaTeX source, bibliography, the PDF, `build.py`, the source audit and
  revision notes, and the executable validation `validate.py` (Python 3, standard
  library only). The validator covers exhaustive stores of up to three records, all
  four-record reference structures up to relabeling, random stores and random protocol
  histories, with and without the acyclic-replay rule. It writes
  `validation-results.json` and the manuscript counts `validation-counts.tex`.
- `paper/engine-trace.json`: written by the tiramemsu engine test
  `engine/export_boundary.rs` (tm-core 0.4.0) with `TM_EXPORT_TRACE` set. The
  validator recomputes the kernels from it independently.
- `lean/`: Lean 4 mechanization of the paper's combinatorial results (core only, no
  Mathlib). `lean/README.md` maps each theorem label to its Lean name and lists what
  is not mechanized.
- `SHA256SUMS`: checksums of every file above.

## Reproduce

    cd paper && python3 validate.py && python3 build.py   # ~1 minute; build needs pdflatex
    cd lean && lake build && lake env lean Axioms.lean

`validate.py` is deterministic. Its results record the SHA-256 of the script and of
the engine trace. Regenerating the trace needs the full repository:

    TM_EXPORT_TRACE=$PWD/paper/statement-as-one-record cargo test -p tm-core --test export_boundary

## Limits

- The PDF's proofs are by hand. The Lean development re-proves the closure, kernel,
  history, encoding, query-view and reifier results under the modelling choices in
  `lean/README.md`. The LPG proposition and the algorithmic cost bounds are not
  mechanized.
- Validation is finite. Engine evidence is limited to the two traced examples.
- No performance claims are made.
